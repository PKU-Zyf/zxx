"""
zxx.Highlight
集锦类
    由视频片段处理组合形成的视频集锦。
"""


from moviepy import VideoClip
from .File import File


class Highlight():
    def __init__(self, contents: VideoClip = None):
        """
        zxx.Highlight 集锦类，由多个经过处理的视频片段组合形成集锦，并对集锦进行配置背景音乐、刷新比分等进一步操作。

        参数说明：
            contents：集锦的初始内容，类型是 moviepy.video 的 VideoClip 类。新建集锦实例时，建议不指定 contents。
        """
        self.__contents = contents
        self.__source_file = None
        self.__score = (0, 0)
        self.__show_score = False
        self.__show_caption = True

    def contents(self) -> VideoClip | None:
        """
        获取视频内容。
        """
        return self.__contents

    def duration(self) -> str:
        """
        获取视频时长。
        """
        from .tools import sec2str
        
        dur = sec2str(self.contents().duration)
        return dur

    def print_duration(self) -> "Highlight":
        """
        打印视频时长。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。
        """
        print(self.duration())
        return self

    # 以下是 Highlight 类独有的方法

    def source_file(self) -> "File":
        """
        返回集锦当前正在处理的视频片段的源文件，类型为 zxx.File。
        """
        return self.__source_file

    def score(self) -> tuple:
        """
        返回当前比分（主队得分在前）。
        """
        return self.__score

    def __add_video(self, clip: VideoClip) -> "Highlight":
        """
        不应外部调用本方法！实际剪辑集锦时，应使用 zxx.Highlight.use() 代替。

        向集锦中追加一段视频片段。如果新追加视频画面尺寸不同，会自动将新视频统一成和已有集锦相同的尺寸。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。

        参数说明：
            video：要追加的视频片段，类型是 moviepy 的 VideoClip 类。
        """
        from moviepy import concatenate_videoclips
        from moviepy.video import fx as vfx

        if self.contents() == None:
            self.__contents = clip
        else:
            # 统一视频尺寸
            hl_size = self.__contents.size
            v_size = clip.size
            if hl_size != v_size:
                new_clip = clip.with_effects([vfx.Resize(hl_size)])
            else:
                new_clip = clip
            self.__contents = concatenate_videoclips([self.contents(), new_clip])
        return self

    def silence(self) -> "Highlight":
        """
        集锦整体消音。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。
        """
        from moviepy.audio import fx as afx

        clip = self.contents()
        clip = clip.with_effects([afx.MultiplyVolume(factor=0)])
        self.__contents = clip
        return self

    def add_bgm(self, filename: str, folder: str = None, 
                select: list = [], repeat: int = 1, mode = "cut") -> "Highlight":
        """
        为集锦添加背景音乐。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。

        参数说明：
            filename：背景音乐的文件名。
            folder：背景音乐文件所在的文件夹绝对路径。如果未指定，则默认为工作目录（即 zxx.options.GetPath() 的返回值）。
            select：选择截取音乐的时间范围。
                写成 ["02:12", "03:06"] 这样的形式。注意开始时刻必须早于结束时刻。
                开始 / 结束时刻如果是空字符串，默认是音乐的开始 / 结束处。
            repeat：设置把截取的音乐片段重复几次（默认为 1，即不重复）
            mode：设置配乐的模式。具体有如下选择：
                mode = "cut"：原速播放音乐，如果视频结束音乐仍未结束，则直接停止音乐。
                mode = "change_music_speed"：自动调整音乐速度，以匹配视频时长。可能导致音乐变调。
        """
        from moviepy import AudioFileClip
        from moviepy import concatenate_audioclips
        from moviepy.video import fx as vfx
        from os.path import join
        from .options import GetPath
        from .tools import str2sec

        if folder == None:
            folder = GetPath()
        video_clip = self.__contents
        audio_clip = AudioFileClip(join(folder, filename))
        if select != []:
            if select[0] == "":
                b = 0
            else:
                b = str2sec(select[0])
            if select[1] == "":
                e = audio_clip.duration
            else:
                e = str2sec(select[1])
            if b >= e:
                raise Exception("背景音乐剪辑错误：开始时间（%s）不早于结束时间（%s）" % (b, e))
            else:
                audio_clip = audio_clip.subclipped(b, e)
        if repeat > 1:
            for i in range(repeat - 1):
                audio_clip = concatenate_audioclips([audio_clip, audio_clip])
        video_duration = video_clip.duration
        audio_duration = audio_clip.duration
        if mode == "cut":               # 视频结束停止音乐
            audio_clip = audio_clip.subclipped(0, video_duration)
            self.__contents = video_clip.with_audio(audio_clip)
        elif mode == "change_music_speed":    # 调整音乐速度，匹配视频时长
            speed = audio_duration / video_duration
            audio_clip = audio_clip.with_effects([vfx.MultiplySpeed(final_duration=video_duration)])
            print("为匹配视频长度，背景音乐速度已调整为原先的 %.2f 倍" % speed)
            self.__contents = video_clip.with_audio(audio_clip)
        else:
            raise Exception("添加背景音乐失败，请指定模式（\"cut\" 或 \"change_music_speed\"）")
        return self

    def use(self, filename: str, folder: str = None) -> "Highlight":
        """
        指定集锦的下一段视频片段使用的视频源文件。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。
        
        参数说明：
            filename：视频文件名。
            folder：视频源文件所在的文件夹绝对路径。如果未指定，则默认为工作目录（即 zxx.options.GetPath() 的返回值）。
        """
        self.__source_file = File(filename, folder)
        return self

    def show_score(self, show: bool = True) -> "Highlight":
        """
        设置是否显示比分牌。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。
        """
        self.__show_score = show
        return self
    
    def show_caption(self, show: bool = True) -> "Highlight":
        """
        设置是否显示字幕。
        如果设为 False，将会忽略所有设置的字幕。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。
        """
        self.__show_caption = show
        return self

    def set_score(self, home: int, away: int) -> "Highlight":
        """
        更新比分。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。

        参数说明：
            home：更新后的主队得分。
            away：更新后的客队得分。
        """
        self.__score = (home, away)
        return self

    def take(self, *args: list) -> "Highlight":
        """
        从正在使用的视频中提取片段，并指定后期处理选项，然后添加至集锦的末尾。
        如果新追加视频画面尺寸不同，会自动将新视频转化成和已有集锦相同的尺寸。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。
        
        这一方法的参数是 *args，即可以传入任意数量的参数。具体用法如下：

            1. 如果不传入任何参数，则将当前正在使用的视频不作任何剪辑或后期处理，直接添加至集锦的末尾。
            2. 如果传入参数，每个参数必须是 list。每个 list 传递从视频文件中截取的一个片段和对应的后期处理信息。
            3. 每个 list 内部元素数量必须是 1 至 4 个：
                (a) 如果是 1 个字符串元素，则代表将当前正在使用的视频不作任何剪辑，只添加字幕，然后添加至集锦的末尾。例如：
                    Highlight().use("素材.mp4").take(["这是一段解说文字！"])
                (b) 如果是 1 个字典元素，则代表将当前正在使用的视频不作任何剪辑，只添加特效，然后添加至集锦的末尾。例如：
                    Highlight().use("素材.mp4").take([{"speed": 0.5, "fadein": 0.2}])
                (c) 如果是 2 个字符串元素，必须是起始时刻和结束时刻，代表将当前正在使用的视频按照该时间范围进行剪辑，不添加任何字幕或特效，然后添加至集锦的末尾。开始 / 结束时刻如果是空字符串，默认是视频的开始 / 结束处。例如：
                    Highlight().use("素材.mp4").take(["00:06", "00:20"])
                    Highlight().use("素材.mp4").take(["", "00:20"])
                    Highlight().use("素材.mp4").take(["00:06", ""])
                (d) 如果是 2 个元素，也可以按照先字幕、后特效的顺序指定，例如：
                    Highlight().use("素材.mp4").take(["这是一段解说文字！", {"speed": 0.5, "fadein": 0.2}])
                (e) 如果是 3 个元素，前 2 个元素必须是起始时刻和结束时刻，第 3 个元素是字幕或特效。例如：
                    Highlight().use("素材.mp4").take(["00:06", "00:20", "这是一段解说文字！"])
                    Highlight().use("素材.mp4").take(["00:06", "", {"speed": 0.5, "fadein": 0.2}])
                (f) 如果是 4 个元素，必须按照起始时刻、结束时刻、字幕、特效的顺序排列。例如：
                    Highlight().use("素材.mp4").take(["00:06", "", "这是一段解说文字！", {"speed": 0.5, "fadein": 0.2}])
            4. 特效元素（dict 类型）会传递到 zxx.tools.effects() 方法作为参数。
                每种特效的键名、值类型和默认值分别为：
                    speed: float = 1, 
                    duration: float | None = None, 
                    silence: bool = False, 
                    lum: float = 0, 
                    contrast: float = 0, 
                    fadein: float = 0, 
                    fadeout: float = 0, 
                    crop: tuple[float, float, float, float] | None = None
                    crop_abs: tuple[int, int, int, int] | None = None, 
                    crop_keep_ratio: tuple[float, float, float] | None = None, 
                    crop_keep_ratio_abs: tuple[int, int, int] | None = None,
                具体意义：
                    speed：调整视频的速度倍数。不可以和 duration 参数一起指定。默认为 1。不建议放慢太多，可能导致时间轴错误。
                    duration：调整视频的速度后，视频片段的持续时间（秒数）。不可以和 speed 参数一起指定。默认为 None。
                    silence：是否消音。
                    lum：亮度要增加或减少的值，大小没有限制，不过一般在 -127 至 127 之间，可自行调试。
                    contrast：对比度要调整的值，大小没有限制，不过一般在 -1 至 1之间，可自行调试。
                    fadein：淡入效果持续的秒数。
                    fadeout：淡出效果持续的秒数。
                    crop 系列参数用于裁剪视频，但注意可能导致比例失真（crop 和 crop_relative）。这四个参数只能同时指定一个。
                        crop：裁切视频指定长方形区域，指定裁切区域左上角和右下角的相对位置。
                            顺序是 (x1, y1, x2, y2)，例如 (2/3, 1/3, 1, 2/3)，表示裁切区域是视频九宫格的右侧居中那格。
                        crop_abs：裁切视频指定长方形区域，依次指定裁切区域左上角和右下角坐标，顺序也是 (x1, y1, x2, y2)，
                            以左上角为 (0, 0)。
                        crop_keep_ratio：裁切视频指定长方形区域，指定裁切区域左上角坐标和右下角横坐标的相对位置。
                            顺序是 (x1, y1, x2)，y2 将根据视频比例自动计算得到。例如 (2/3, 1/3, 1)，
                            表示裁切区域是视频九宫格的右侧居中那格。
                        crop_keep_ratio_abs：裁切视频指定长方形区域，依次指定裁切区域左上角坐标和右下角横坐标，
                            顺序也是 (x1, y1, x2)，y2 将根据视频比例自动计算得到。
        """
        from .tools import add_effects, add_caption, add_scoreboard, add_caption_and_scoreboard

        # 不传入任何参数的情况
        if len(args) == 0:
            args = [["", ""]]
        # 分析参数
        for info in args:
            has_scoreboard = False
            if len(info) >= 5:
                raise Exception("*args 中某一项包含元素过多，必须是 1 至 4 个！")
            if len(info) == 1:    # 处理只传入 1 个元素的情况
                info = ["", "", info[0]]
            elif len(info) == 2:    # 处理传入 2 个元素为字幕和特效的情况
                if isinstance(info[1], dict):
                    info = ["", "", info[0], info[1]]
            # 现在 info 中至少有 3 个参数了，且前 2 个参数分别是起始时刻和结束时刻
            # 设定起始时刻和结束时刻，然后截取视频片段
            begin = info[0]
            end = info[1]
            if begin == "":
                begin = "0"
            if end == "":
                end = str(self.source_file().contents().duration)
            clip = self.source_file().select(begin, end)
            # 4 个参数的情况：添加特效和字幕，顺序是先加特效，再加字幕
            if len(info) == 4:
                effects = info[3]
                clip = add_effects(clip, **effects)
                if self.__show_caption:
                    caption = info[2]
                    # 判断是否同时加比分牌
                    if self.__show_score:
                        home_score, away_score = self.score()
                        clip = add_caption_and_scoreboard(clip, caption, home_score, away_score)
                        has_scoreboard = True
                    else:
                        clip = add_caption(clip, caption)
            # 3 个参数的情况：只添加特效或字幕，需要判断一下是哪个
            elif len(info) == 3:
                if isinstance(info[2], dict):
                    effects = info[2]
                    clip = add_effects(clip, **effects)
                else:
                    if self.__show_caption:
                        caption = info[2]
                        # 判断是否同时加比分牌
                        if self.__show_score:
                            home_score, away_score = self.score()
                            clip = add_caption_and_scoreboard(clip, caption, home_score, away_score)
                            has_scoreboard = True
                        else:
                            clip = add_caption(clip, caption)
            # 补充添加比分牌
            if self.__show_score and not has_scoreboard:
                home_score, away_score = self.score()
                clip = add_scoreboard(clip, home_score, away_score)
            self.__add_video(clip)
        return self

    def export(self, filename: str, folder: str = None, mode: str = "hd", threads: int | None = None) -> "Highlight":
        """
        将整个集锦导出成视频文件。
        返回值是 self，即调用该函数的实例本身，因此可用于链式写法。

        参数说明：
            filename：导出的视频文件名。
            folder：导出的视频文件所在的文件夹绝对路径。如果未指定，则默认为工作目录（即 zxx.options.GetPath() 的返回值）。
            mode：导出模式。可设置以下模式：
                mode = "preview"：用于导出快速预览，视频文件会很小，建议导出文件名选择 .mp4 后缀。
                mode = "hd"：高清画质，视频压缩效果好，建议导出文件名选择 .mp4 后缀。
                mode = "DJI Action 4"：匹配大疆 Action 4 画质，建议导出文件名选择 .mp4 后缀。
                mode = "lossless"，无损画质，文件非常大，不推荐使用。建议导出文件名选择 .avi 后缀。
            threads：导出时的线程数，默认为 None 即不使用多线程。不推荐使用，因为似乎没有什么用处。
        """
        from os.path import join
        from .options import GetPath

        if folder == None:
            folder = GetPath()
        output_path = join(folder, filename)
        # 快速导出
        if mode == "preview":
            self.__contents.write_videofile(
                output_path,
                fps = 24,
                preset = "ultrafast",
                bitrate = "1000k",
                threads = threads,
            )
        # 高清画质
        ## 视频质量通过 bitrate 参数调节，B 站推荐 4K 视频码率大于 20000kbps
        elif mode == "hd":
            self.__contents.write_videofile(
                output_path,
                codec = "libx264",
                bitrate = "20000k",
                threads = threads,
            )
        # 匹配大疆 Action 4 画质
        elif mode == "DJI Action 4":
            self.__contents.write_videofile(
                output_path,
                fps = 59.94,
                codec="libx264",
                bitrate="100000k",
                threads = threads,
            )
        # 无损画质
        elif mode == "lossless":
            self.__contents.write_videofile(
                output_path,
                codec = "png",
                bitrate = "20000k",
                threads = threads,
            )
        print("视频已导出至 %s" % output_path)
        return self
    
    def change_match_info(self, home: str = "", away: str = "") -> "Highlight":
        """
        中途修改比赛信息（主客队信息），用于制作多场比赛的集锦。
        """
        from .options import SetMatchInfo

        if home != "" and away != "":
            SetMatchInfo(home=home, away=away)
        elif home != "":
            SetMatchInfo(home=home)
        elif away != "":
            SetMatchInfo(away=away)
        return self
    
    def preview_frame(self, filename: str, t: float | tuple | str = 0, folder: str | None = None) -> "Highlight":
        """
        保存指定时刻的帧，可以用于预览视频效果。
        默认导出首帧。默认保存在工作目录。
        参数 t 指定时刻：
            可以是秒数：t = 15.35
            可以是元组形式的 (min, sec) 或 (hour, min, sec)：t = (1, 3, 5.35)
            可以是字符串: t = "01:03:05.35"
            特别地，指定 t = "last" 时，保存最后一帧。指定 t = "second_last" 时，保存倒数第二帧。
        """
        from os.path import join
        from .options import GetPath

        if folder == None:
            folder = GetPath()
        output_path = join(folder, filename)
        if t == "last":
            # 获取最后一帧
            t = self.__contents.duration
        if t == "second_last":
            # 获取倒数第二帧
            fps = self.__contents.fps
            t = self.__contents.duration - 1 / fps
        self.__contents.save_frame(filename=output_path, t=t)
        print(f"第 {t} 秒的帧已保存至 {output_path}")
        return self

    # def clear(self):
    #     """
    #     释放所有正在使用 clips，建议在导出视频之后调用，以关闭多余的子进程。
    #     """
    #     from moviepy.tools import close_all_clips
    #     close_all_clips()
    #     return self

