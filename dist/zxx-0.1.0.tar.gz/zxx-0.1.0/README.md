# zxx

* 北京大学政信信女足开发的Python库，主要用于剪辑比赛集锦。 / A Python package developed by “Zheng Xin Xin”Women’s Football Team at Peking University, mainly used for editing game highlights.

* 点击[此处](https://github.com/PKU-Zyf/zxx)前往zxx的GitHub主页。 / Click [here](https://github.com/PKU-Zyf/zxx) to go to the GitHub homepage of  *zxx*.

* 点击[此处](https://pypi.org/project/zxx)前往zxx的PyPI主页。 / Click [here](https://pypi.org/project/zxx) to go to the PyPI homepage of *zxx*.

* 安装 / To install: `pip install zxx`.

* 更新 / To update: `pip install --upgrade zxx` / `pip install -U zxx`.

  ## 更新日志 Update Logs

* 0.1.0 (2022-11-07)

  * 第一次正式发布。 / The first release.
